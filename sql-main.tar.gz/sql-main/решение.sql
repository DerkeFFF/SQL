-- Модуль 5
-- 5А
SELECT subject_name, hours FROM subjects
WHERE hours > 60 ORDER BY hours DESC;
-- 5Б
SELECT s.last_name, s.first_name
FROM students s JOIN groups g ON g.group_id=s.group_id
WHERE g.group_name='ИС-21'
ORDER BY s.last_name, s.first_name;

-- Модуль 6
-- 6А
SELECT group_id, COUNT(*) AS student_count
FROM students GROUP BY group_id ORDER BY group_id;
-- 6Б
SELECT ROUND(AVG(grade),2) AS average_grade
FROM grades WHERE subject_id=1;

-- Модуль 7 / 7А
SELECT t.last_name, t.first_name, sub.subject_name,
       COUNT(gr.grade_id) AS grades_count
FROM grades gr
JOIN teachers t ON t.teacher_id=gr.teacher_id
JOIN subjects sub ON sub.subject_id=gr.subject_id
GROUP BY t.teacher_id, sub.subject_id
ORDER BY t.last_name, t.first_name, sub.subject_name;

-- Итоговое задание 1
SELECT g.group_name, COUNT(s.student_id) AS student_count
FROM groups g LEFT JOIN students s ON s.group_id=g.group_id
GROUP BY g.group_id, g.group_name
ORDER BY student_count DESC, g.group_name;

-- Итоговое задание 2
SELECT s.last_name, s.first_name, g.group_name,
       ROUND(AVG(gr.grade),2) AS average_grade
FROM students s
JOIN groups g ON g.group_id=s.group_id
JOIN grades gr ON gr.student_id=s.student_id
GROUP BY s.student_id, s.last_name, s.first_name, g.group_name
ORDER BY average_grade DESC, s.last_name, s.first_name;

-- Итоговое задание 3
SELECT s.last_name, s.first_name
FROM students s JOIN grades gr ON gr.student_id=s.student_id
GROUP BY s.student_id, s.last_name, s.first_name
HAVING AVG(gr.grade)=5
ORDER BY s.last_name, s.first_name;

-- Итоговое задание 4
SELECT t.last_name, t.first_name, COUNT(gr.grade_id) AS grades_count
FROM teachers t JOIN grades gr ON gr.teacher_id=t.teacher_id
GROUP BY t.teacher_id, t.last_name, t.first_name
ORDER BY grades_count DESC LIMIT 1;

-- Дополнительный общий отчёт
SELECT s.last_name AS student, g.group_name AS student_group,
       sub.subject_name AS subject, t.last_name AS teacher,
       gr.grade, gr.grade_date
FROM grades gr
JOIN students s ON s.student_id=gr.student_id
JOIN groups g ON g.group_id=s.group_id
JOIN subjects sub ON sub.subject_id=gr.subject_id
JOIN teachers t ON t.teacher_id=gr.teacher_id
ORDER BY gr.grade_date;